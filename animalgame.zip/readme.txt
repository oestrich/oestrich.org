In order to run Animal Game please call this from the same directory as animalgame.jar:

java -jar animalgame.jar

The user Eric already has past history.


Copyright 2009 Eric Oestrich